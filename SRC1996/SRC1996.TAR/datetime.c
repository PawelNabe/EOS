static char version[] = __VERSION__;

int main()
{
	puts(version);
	return(0);
} /* main */

